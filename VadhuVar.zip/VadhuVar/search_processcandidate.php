<!DOCTYPE html>
<html lang="en">
  <!-- Mirrored from www.mangalashtak.com/searchoption.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jul 2020 05:27:50 GMT -->
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>वधू - वर सूचक : searchOption</title>
    <meta
      name="keywords"
      content="Matrimony,Matrimonial, Search Options,Partner Search,All Matrimony searches"
    />
    <meta name="Description" content="" />
    <meta name="robots" content="NOODP" />
    <meta name="theme-color" content="#e91e63" />
    <link href="fonts/opensans.css" rel="stylesheet" type="text/css" />
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link href="css/common.css" rel="stylesheet" />
    <link href="css/form.css" rel="stylesheet" />
    <link href="css/profile.css" rel="stylesheet" />
    <link href="css/search_result.css" rel="stylesheet" />
    <link href="css/membership.css" rel="stylesheet" />
    <link href="css/static_content.css" rel="stylesheet" />
    <link href="css/gallery.css" rel="stylesheet" />
    <link href="css/mainstyle.css" rel="stylesheet" />
    <link href="css/media_query.css" rel="stylesheet" />
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.min.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <header>
      <div class="topbar">
        <div class="container">
          <marquee>
            <font color="#ff6600" size="4px"
              >वधू - वर सूचक. नातं मराठी मनाचं..... आम्ही तुमच्या साठी उत्तम
              जोडीदार शोधला मदत करू.
            </font>
          </marquee>
        </div>
      </div>
      <div class="headerbar">
        <div class="container">
          <div class="logo">
            <a href=" " title="Vadhu Var Suchak"
              ><img src="images\logo.png" alt=""
            /></a>
          </div>
          <button class="toggleButton">
            <span></span>
            <span></span>
            <span></span>
          </button>
          <nav>
            <ul>
              <li class="active"><a href="index.html">Home</a></li>
              <!--<li><a href="javascript:;" data-toggle="modal" data-target="#myLoginModal">Login</a></li>-->
              <li><a href="login.html">Login</a></li>
              <li><a href="registration.html">Register</a></li>
              
              <li><a href="membership.html">Membership</a></li>
              <li><a href="contactus.html">Contact Us</a></li>
              <li><a href="help.html">Help</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </header>

    
    <section class="titleWrapper">
      <div class="container">
        <h1>All Data</h1>
      </div>
    </section>

        
<!-- PHP-->
<?php  
    include 'connect_db.php';  

    if(isset($_POST["Qualification"]) and isset($_POST["district"]))
    {
      $qualification = $_POST["Qualification"];
      $district = $_POST["district"];
      $sql = "select * from register, profile where register.id=profile.id and qualification='".$_POST["Qualification"]."' and add_district='". $district. "'";
    }
    else if(isset($_POST["Qualification"]))
    {
      $qualification = $_POST["Qualification"];
      $sql = "select * from register, profile where register.id=profile.id and qualification='".$_POST["Qualification"]."'";
    }
    else if(isset($_POST["district"]))
    {
      $district = $_POST["district"];
      $sql = "select * from register, profile where register.id=profile.id and add_district='".$_POST["district"]."'";
    }
    

    else
    {
      $sql = "select * from register,profile where register.id=profile.id";
    }
    
  
    
    $result = $conn->query($sql);
    //echo "Total Columns : ". $result->field_count. "<br>";

    /*Show Column Names:
    $sql2 = "SHOW COLUMNS FROM vacancy";
    $result2 = $conn->query($sql2); */
  ?>

  <!-- ======= Recruitment Section ======= -->    
  
   <?php
  
      /* To Show Columns from database        
        $column_names=array();
        $i=0;
        while($row2 = $result2->fetch_assoc()){
          array_push($column_names, $row2['Field']);    
          $i++;     
        }  
      */
  
      // The code where td for each column
      if ($result->num_rows > 0) {    
        // output data of each row
        $row_flag=2;
        while($row = $result->fetch_assoc()) {
          
	?>
		<section class="wrapper search_result">
       <div class="container">
        <div class="row clearfix">
           <h5 class="Ourvarious"> Users   <?php echo "<span>". $row["id"]. "</span>" ;  ?>  </h5>
              <div class="col-lg-9 keepcenter">
                <ul class="result">
                    <li>
          <?php
            echo "<h4>" . $row["fname"]. "  ".$row["mname"]. "  ".$row["lname"] . "</h4>";
?>
            <div  class="clearfix">
			         <div class="left col-lg-4">
				          <a href="" data-toggle="modal"  class="img"> <?php echo  "<img src='upload/pic/". $row["photo"]. "' >"  ; ?>    </a>
               </div>
          
                                    <div class="right col-lg-8">
                                      <div class="aboutSummary">
				                               <div class="groupinfo clearfix">
					                                <div class="group fullwidth">
						                                <label> Gender </label>
						                                <?php echo "<span>". $row["gender"]. "</span>" ;  ?> 
                                            <label> Birth Date </label>
						                                <?php echo "<span>". $row["date1"] ."-". $row["month1"]."-". $row["year1"]. "</span>" ;  ?>
                                            <label> Marital Status</label>
						                                <?php echo "<span>". $row["m_status"] . " ". $row["nc"] . " ". $row["clwm"]. "</span>" ;  ?>
                                            <label> Religion </label>
						                                <?php echo "<span>". $row["religion"] ."&nbsp&nbsp&nbsp&nbsp". $row["caste"]."&nbsp&nbsp&nbsp&nbsp". $row["subcaste"]. "</span>" ;  ?>
                                            <label> Email Id </label>
						                                <?php echo "<span>". $row["emailid"]. "&nbsp&nbsp&nbsp&nbsp Created By: " . $row["created_by"]. "</span>" ;  ?> 
                                            <label> Mobile No. </label>
						                                <?php echo "<span>". $row["mobile1"] . "&nbsp&nbsp&nbsp&nbsp Alternate No:". $row["mobile2"]. "</span>" ;  ?> 
                                            <label> Gothra </label>
						                                <?php echo "<span>".  $row["gothra"] ."&nbsp&nbsp&nbsp&nbsp MoonSign:   ". $row["moonsign"] . "</span>" ;  ?> 
                                            <label> Horos </label>
						                                <?php echo "<span>". $row["horos"] . "&nbsp&nbsp&nbsp&nbsp Manglik: ". $row["manglik"] . "</span>" ;  ?> 
                                            <label> Birth Place </label>
						                                <?php echo "<span>".  $row["birth_village"] .",&nbsp".$row["birth_city"] .",&nbsp".$row["birth_taluka"] .",&nbsp". $row["birth_district"] .",&nbsp". $row["birth_state"] .",&nbsp". $row["birth_country"] . "</span>" ;  ?> 
                                            <label> Birth Time </label>
						                                <?php echo "<span>". $row["birth_hour"] . "-". $row["birth_min"] ." ".$row["ampm"] . "</span>" ;  ?> 
					                                  <label> Height </label>
						                                <?php echo "<span>". $row["height_cm"] . " &nbsp&nbsp&nbsp&nbspWeight: ". $row["weight_kg"]. "</span>" ;  ?> 
                                            <label> Blood Group </label>
						                                <?php echo "<span>". $row["blood"] ."</span>" ;  ?> 
                                            <label> Complexion </label>
						                                <?php echo "<span>". $row["complexion"]. "</span>" ;  ?> 
                                            <label> Physical Status </label>
						                                <?php echo "<span>". $row["p_status"] ." Other:".  $row["physicalsts"]. " &nbsp&nbsp&nbsp&nbspBody Type: ". $row["body_type"]. "</span>" ;  ?> 
                                            <label> Qualification </label>
						                                <?php echo "<span>". $row["qualification"] . "</span>" ;  ?> 
                                            <label> Occupation </label>
						                                <?php echo "<span>". $row["occupation"] . "</span>" ;  ?> 
                                            <label> Current Address </label>
						                                <?php echo "<span>".  $row["address1"]. ",&nbsp<b>".$row["add_city"]. "</b>,&nbsp". $row["add_district"]. ",&nbsp". $row["add_state"]. ",&nbsp". $row["add_country"].  "</span>" ;  ?> 
                                            <label> Diet </label>
						                                <?php echo "<span>". $row["diet"] . "</span>" ;  ?> 
                                            <label> Smoke </label>
						                                <?php echo "<span>". $row["smoke"]. " &nbsp&nbsp Drink:". $row["drink"]. "</span>" ;  ?> 
                                            
						                                <h5 align="center"><?php echo  "<a href='upload/biodata/". $row["biodata"]. "' target='_new'>". "View Bio Data" . "</a> "; ?> </h5>
                                            
                                          </div>
					                            </div>
                                    </div>
             </div> 
             <?php
                $dates2 = explode(' ', $row["last_update"]);
                $dat = $dates2[0];
              ?>
                  <h5><?php echo "<td>" . "Last Updated on " . $dat . "</td>";  ?>     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspNote :- All information is entered by User by Own.</h5>
          </li>
          </ul>
          </div>
        </div>  
      </div>    
    </section>    
           <!-- End of <div class="row">    -->      
                   
      <?php      
      } //End of While loop
      ?>
    
  
  <?php
  }   
  else {
    echo "Sorry for Inconvenience. Technical Problem.";
  }

  $conn->close();
?>



 <footer>
      <!-- <div class="subscribeWrapper">
              <div class="container">
                <input type="email" placeholder="Enter Your Email" class="email">
                <input type="submit" class="btn btnSubmit" value="Subscribe">
              </div>
            </div> -->
      <div class="container fttop">
        <div class="col col-lg-4 col-md-4 col-sm-4">
          <h2>About Us</h2>
          <ul>
            <li><a href="aboutus.html">About Vadhu Var Suchak &raquo;</a></li>
            <li><a href="contactus.html">Contact Us &raquo;</a></li>
          </ul>
        </div>
        <div class="col col-lg-4 col-md-4 col-sm-4">
          <h2>Information</h2>
          <ul>
            <li><a href="privacy.html">Privacy Policy &raquo;</a></li>
            <li><a href="help.html">Help &raquo;</a></li>
            <li><a href="contactus.html">Contact Us &raquo;</a></li>
          </ul>
        </div>
        <div class="col col-lg-4 col-md-4 col-sm-4">
          <h2>Social Media</h2>
          <ul>
            <li><a href="#" class="fa fa-facebook"></a></li>
            <li><a href="#" class="fa fa-twitter"></a></li>
            <li><a href="#" class="fa fa-youtube"></a></li>
            <li><a href="#" class="fa fa-instagram"></a></li>
          </ul>
        </div>
      </div>
      <div class="ftbottom">
        <div class="container">
          Copyright &copy; 2020Omist.in - All rights reserved.
        </div>
      </div>
    </footer>

    <!--<a href="#top" id="toTop"><i aria-hidden="true" class="glyphicon glyphicon-upload"></i></a>-->
    <a href="javascript:void(0)" id="toTop" onclick="topFunction()"
      ><i aria-hidden="true" class="glyphicon glyphicon-upload"></i
    ></a>
    <!-- End Footer -->
    <script type="text/JavaScript">
      <!--
      function MM_openBrWindow(theURL,winName,features) { //v2.0
        window.open(theURL,winName,features);
      }
      //-->
    </script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    <script type="text/javascript">
      var gaJsHost =
        "https:" == document.location.protocol ? "https://ssl." : "http://www.";
      document.write(
        unescape(
          "%3Cscript src='" +
            gaJsHost +
            "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"
        )
      );
      window.onscroll = function() {
        scrollFunction();
      };

      function scrollFunction() {
        if (
          document.body.scrollTop > 20 ||
          document.documentElement.scrollTop > 20
        ) {
          document.getElementById("toTop").style.display = "block";
        } else {
          document.getElementById("toTop").style.display = "none";
        }
      }

      // When the user clicks on the button, scroll to the top of the document
      function topFunction() {
        document.body.scrollTop = 0; // For Chrome, Safari and Opera
        document.documentElement.scrollTop = 0; // For IE and Firefox
      }
    </script>
    <script type="text/javascript">
      try {
        var pageTracker = _gat._getTracker("UA-6395437-3");
        pageTracker._trackPageview();
      } catch (err) {}
    </script>
  </body>

  <!-- Mirrored from www.mangalashtak.com/searchoption.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 07 Jul 2020 05:27:52 GMT -->
</html>
